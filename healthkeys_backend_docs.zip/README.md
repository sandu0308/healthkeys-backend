# HealthKeys Backend

Бұл серверлік бөлік **HealthKeys** веб-сайтына арналған – медициналық кеңестер мен фитнес бағдарламаларын ұсынатын платформа.

## 📦 Технологиялар

- Node.js
- Express
- MongoDB (Atlas)
- Mongoose
- JWT авторизация
- bcrypt (парольді шифрлау)

## 🚀 Қалай іске қосуға болады

1. Репозиторийді клондаңыз:
   ```bash
   git clone https://github.com/sandu0308/healthkeys-backend.git
   cd healthkeys-backend
   ```

2. Қажетті пакеттерді орнатыңыз:
   ```bash
   npm install
   ```

3. `.env` файлын жасаңыз және мынадай мәндерді жазыңыз:
   ```
   PORT=5000
   MONGO_URL=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret
   ```

4. Серверді іске қосыңыз:
   ```bash
   npm run dev
   ```

## 📁 Құрылымы

```
healthkeys-backend/
├── controllers/
├── routes/
├── models/
├── middleware/
├── index.js
├── .env (локалды)
├── .gitignore
├── package.json
```

## 🧠 Автор
Sandugash Adylbek – дипломдық жұмыс үшін.
